import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Library library = new Library();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nLibrary Menu:");
            System.out.println("1. Add a book");
            System.out.println("2. Borrow a book");
            System.out.println("3. Return a book");
            System.out.println("4. Display available books");
            System.out.println("5. Display borrowed books");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter book title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter book author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter book ISBN: ");
                    String ISBN = scanner.nextLine();
                    library.addBook(new Book(title, author, ISBN));
                    System.out.println("Book added successfully.");
                    break;
                case 2:
                    System.out.print("Enter book ISBN to borrow: ");
                    String borrowISBN = scanner.nextLine();
                    if (library.borrowBook(borrowISBN)) {
                        System.out.println("Book borrowed successfully.");
                    } else {
                        System.out.println("Book not found or already borrowed.");
                    }
                    break;
                case 3:
                    System.out.print("Enter book ISBN to return: ");
                    String returnISBN = scanner.nextLine();
                    if (library.returnBook(returnISBN)) {
                        System.out.println("Book returned successfully.");
                    } else {
                        System.out.println("Book not found or not borrowed by you.");
                    }
                    break;
                case 4:
                    library.displayAvailableBooks();
                    break;
                case 5:
                    library.displayBorrowedBooks();
                    break;
                case 6:
                    System.out.println("Exiting the Library System.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}